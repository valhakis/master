#include <stdio.h>

int main()
{
  puts("little main function yo yo yolo");
  return 0;
}
